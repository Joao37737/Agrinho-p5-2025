let fishermanX;
let fishermanY;
let fishX;
let fishY;
let hookX;
let hookY;
let isFishing = false;
let fishCaught = false;
let score = 0;
let hookSpeed = 40; // Velocidade do anzol aumentada para 10

function setup() {
  createCanvas(600, 400);
  resetGame();
}

function resetGame() {
  fishermanX = width / 2;
  fishermanY = height - 50;
  fishX = random(50, width - 50);
  fishY = random(50, height - 100);
  hookX = fishermanX;
  hookY = fishermanY;
  isFishing = false;
  fishCaught = false;
}

function draw() {
  background(135, 206, 235); // Fundo azul claro

  // Desenha a água
  fill(0, 0, 255, 100);
  rect(0, height - 100, width, 100);

  // Desenha o pescador
  fill(101, 67, 33);
  rect(fishermanX - 20, fishermanY - 40, 40, 40); // Corpo
  fill(0);
  ellipse(fishermanX, fishermanY - 45, 20, 20); // Cabeça

  // Desenha a linha e o anzol
  stroke(0);
  line(fishermanX, fishermanY - 35, hookX, hookY);
  fill(150);
  ellipse(hookX, hookY, 10, 10); // Anzol

  // Desenha o peixe
  fill(255, 165, 0);
  ellipse(fishX, fishY, 30, 20);

  // Mostra a pontuação
  fill(0);
  textSize(20);
  text("Pontuação: " + score, 20, 30);

  if (isFishing) {
    // O movimento do anzol agora é controlado pelas setas para cima e para baixo
    let d = dist(hookX, hookY, fishX, fishY);
    if (d < 20 && !fishCaught) {
      fishCaught = true;
      console.log("Peixe fisgado!");
    }

    if (fishCaught) {
      fishX = hookX;
      fishY = hookY;
      hookY -= hookSpeed; // Puxa o peixe para cima
      if (hookY < fishermanY - 35) { // Quando o anzol passa pela cabeça do pescador
        score++;
        resetGame();
      }
    }
  } else {
    // Move o anzol horizontalmente junto com o pescador quando não está pescando
    hookX = fishermanX;
    hookY = fishermanY;
  }
}

function keyPressed() {
  if (!isFishing) {
    if (keyCode === LEFT_ARROW) {
      fishermanX -= 10;
    } else if (keyCode === RIGHT_ARROW) {
      fishermanX += 10;
    } else if (keyCode === DOWN_ARROW) {
      isFishing = true;
      hookX = fishermanX;
      hookY = fishermanY;
      fishCaught = false;
    }
    fishermanX = constrain(fishermanX, 20, width - 20);
  } else {
    if (keyCode === UP_ARROW) {
      hookY -= hookSpeed;
    } else if (keyCode === DOWN_ARROW) {
      hookY += hookSpeed;
    }
    // Adicione limites para o anzol não ir muito para cima
    hookY = constrain(hookY, 0, fishermanY);
  }
}